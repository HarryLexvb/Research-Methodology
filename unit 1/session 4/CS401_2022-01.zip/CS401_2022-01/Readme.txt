1. Descomprimir el archivo PlantillaProyectoI.rar en el disco.
2. En la ventana de comandos moverse a la carpeta descomprimida
3. usar C:\<carpetaDescomprimida>\pdflatex PlantillaProyectoI.tex